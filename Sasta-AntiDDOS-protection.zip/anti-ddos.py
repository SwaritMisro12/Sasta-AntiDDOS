from flask import Flask, request, render_template, jsonify
import threading
import time

app = Flask(__name__)

attack_threshold = 1000  # Adjust this threshold as needed
block_duration = 300  # Block time in seconds
blocked_ips = {}  # Dictionary to store blocked IPs and their unblock time

def block_ip(ip):
    blocked_ips[ip] = time.time() + block_duration

def unblock_ip(ip):
    if ip in blocked_ips:
        del blocked_ips[ip]

def is_blocked(ip):
    return ip in blocked_ips and time.time() < blocked_ips[ip]

def monitor_requests():
    while True:
        try:
            time.sleep(1)
            for ip, unblock_time in list(blocked_ips.items()):
                if time.time() >= unblock_time:
                    unblock_ip(ip)
        except KeyboardInterrupt:
            break

monitor_thread = threading.Thread(target=monitor_requests)
monitor_thread.start()

@app.route('/')
def index():
    client_ip = request.remote_addr
    if is_blocked(client_ip):
        return "This site is currently down for maintenance due to a DDoS attack."

    return "index.html"

@app.route('/report_attack', methods=['POST'])
def report_attack():
    client_ip = request.remote_addr
    if request.method == 'POST':
        block_ip(client_ip)
        return jsonify(message="Attack reported. The site is now protected against DDoS attacks from this IP.", blocked=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
