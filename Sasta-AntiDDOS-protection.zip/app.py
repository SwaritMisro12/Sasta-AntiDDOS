from flask import Flask, request, render_template, redirect, session, jsonify
import time
import json
import psutil
import threading
from scapy.all import sniff
import socket 



app = Flask(__name__)
app.secret_key = 'tab*F0O424B#'
app_keys = {'tab*F0O424B#'}  # Replace with your actual keys

ip_last_access = {}
user_logs = []  # List to store user logs
dns_records = []
request_counts = {}
alerts = []


records = [
    {'domain': 'example.com', 'ip_address': '192.168.1.2'},
    {'domain': 'example.org', 'ip_address': '192.168.1.3'}
]



BOT_USER_AGENTS = [
    'bot', 'spider', 'crawler', 'search', 'curl', 'wget', 'httpie', 'python-requests'
]
REDIRECT_COOLDOWN = 10
ACCESS_LIMIT = 30  # Time window in seconds for accessing the site
MAX_REQUESTS = 50  # Change this to your desired limit
REQUEST_WINDOW = 60  # Time window in seconds
BANDWIDTH_LIMIT = 1000  # 1000 bytes per second


def add_dns_record(record):
    dns_records.append(record)


def check_for_bot_activity(user_agent):
    if is_bot(user_agent):
        alerts.append(f"Bot activity detected: User-Agent - {user_agent}")


def can_access_again(client_ip):
    last_access_time = ip_last_access.get(client_ip)
    if last_access_time is None:
        return True

    current_time = time.time()
    return current_time - last_access_time >= REDIRECT_COOLDOWN

def can_access_site(client_ip):
    last_access_time = ip_last_access.get(client_ip)
    if last_access_time is None:
        return True

    current_time = time.time()
    return current_time - last_access_time >= ACCESS_LIMIT

def get_network_usage():
    network_info = psutil.net_io_counters()
    return network_info.bytes_sent, network_info.bytes_recv

def start_packet_capture():
    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
            sock.bind(('192.168.1.2', 0))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            sock.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)

            while True:
                packet, _ = sock.recvfrom(65565)
                process_packet(packet)
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(1)


def is_bot(user_agent):
    user_agent_lower = user_agent.lower()
    for bot_keyword in BOT_USER_AGENTS:
        if bot_keyword in user_agent_lower:
            return True
    return False

def can_access_site(client_ip):
    current_time = time.time()
    if client_ip in ip_last_access:
        last_access_time = ip_last_access[client_ip]
        elapsed_time = current_time - last_access_time
        if elapsed_time < 30:  # Wait 30 seconds before allowing access again
            return False
    ip_last_access[client_ip] = current_time
    return True



# Load settings.json
with open('settings.json') as settings_file:
    settings = json.load(settings_file)
    app_keys = settings.get('app_keys', [])
    app_key = settings.get('control_panel_key', '')  # Extract the control panel key

@app.route('/')
def index():
    client_ip = request.remote_addr
    user_agent = request.headers.get('User-Agent')

    if 'redirected' in session and not can_access_again(client_ip):
        return "It is not possible to access this regarding the protection, you need to wait 30 seconds"
    if not can_access_site(client_ip):
        return "Access to the site is limited to once every 30 seconds."
    if is_bot(user_agent):
        return "Bot detected and blocked."

    check_for_bot_activity(user_agent)

    if 'redirected' in session and not can_access_again(client_ip):
        alerts.append(f"Access denied due to too many requests: IP - {client_ip}")
        return "It is not possible to access this regarding the protection, you need to wait 30 seconds"
    
    if not can_access_site(client_ip):
        alerts.append(f"Access denied due to frequent requests: IP - {client_ip}")
        return "Access to the site is limited to once every 30 seconds."


    session['redirected'] = True
    ip_last_access[client_ip] = time.time()

    user_logs.append({'ip': client_ip, 'user_agent': user_agent, 'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')})
    
    return render_template('index.html', ip=client_ip, user_agent=user_agent)

bandwidth = 1000



def unblock_ip_periodically(ip_address, unblock_time):
    time.sleep(unblock_time)
    if ip_address in blocked_ips:
        blocked_ips.remove(ip_address)
        subprocess.run(['iptables', '-D', 'INPUT', '-s', ip_address, '-j', 'DROP'])

# Simulate detection of malicious IP addresses
def detect_malicious_ips():
    while True:
        # Replace this with your actual logic to detect malicious IPs
        malicious_ips = ['1.2.3.4', '5.6.7.8']
        for ip in malicious_ips:
            block_ip(ip)
            unblock_time = 60  # Unblock after 1 minute
            unblock_thread = threading.Thread(target=unblock_ip_periodically, args=(ip, unblock_time))
            unblock_thread.start()
        time.sleep(10)  # Run the detection every 10 seconds

# Define a route to activate L4 protection
@app.route('/activate_l4', methods=['POST'])
def activate_l4_protection():
    if request.method == 'POST':
        detect_thread = threading.Thread(target=detect_malicious_ips)
        detect_thread.start()
        return "L4 Protection activated successfully"
    return "Invalid request"





# Function to handle adding DNS records from the control panel
@app.route('/dns_records', methods=['GET'])
def dns_records():
    return render_template('dns_records.html', records=records)

@app.route('/add_dns_record', methods=['POST'])
def add_dns_record():
    ip_address = request.form.get('ip')
    dns_record = request.form.get('dns_record')
    
    # Save the data to your backend (e.g., a list, database, etc.)
    new_record = {'domain': dns_record, 'ip_address': ip_address}
    records.append(new_record)
    
    # Redirect back to the DNS records page
    return redirect('/dns_records')

def calculate_bandwidth_usage():
    global bandwidth
    while True:
        # Logic to calculate bandwidth usage
        # Replace this with your actual implementation
        bandwidth += 100  # Example increment in bandwidth value
        time.sleep(5)  # Wait for 5 seconds before updating bandwidth value

@app.route('/control_panel', methods=['GET', 'POST'])
def control_panel():
    global bandwidth
    if request.method == 'POST':
        entered_key = request.form['key'] if 'key' in request.form else None
        if entered_key == app_key:  # Check if the entered key is correct
            # Code to handle bandwidth usage calculation
            # Start the bandwidth calculation thread
            bandwidth_thread = threading.Thread(target=calculate_bandwidth_usage)
            bandwidth_thread.start()

            return render_template('control_panel.html', logs=user_logs, bandwidth=bandwidth)
        else:
            return "Access Denied"

    return render_template('login.html')

@app.route('/live_info')
def live_info():
    threads = psutil.cpu_count()
    requests = len(user_logs)
    return jsonify({'threads': threads, 'requests': requests})

@app.route('/network_usage')
def network_usage():
    bytes_sent, bytes_recv = get_network_usage()
    return jsonify({'bytes_sent': bytes_sent, 'bytes_recv': bytes_recv})

if __name__ == '__main__':
    # Start the packet capture thread
    capture_thread = threading.Thread(target=start_packet_capture)
    capture_thread.start()
    app.run(host='0.0.0.0', port=80)
